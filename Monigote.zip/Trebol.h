#pragma once
#include "Base.h"
class Trebol :public Base
{
public:

	Trebol(int px, int py):Base (px,py)
	{
		dy = rand() % 2 + 1;
	}

	void dibujar()
	{
		Console::ForegroundColor = ConsoleColor::Green;
		Console::SetCursorPosition(x, y);
		cout << char(5);
	}


}; 
