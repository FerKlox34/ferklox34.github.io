#include "Manejadora.h"
int main()
{
	Console::CursorVisible = false;
	Console::SetWindowSize(ANCHO, ALTO);
	Manejador* oManejador = new Manejador();

	int v = oManejador->devolverVidas();
	int tiempoC = 0;
	int tiempoT = 0;

	while (v!=0)
	{
		srand(time(NULL));
		if (tiempoC > rand() % 15 + 1)
		{
			oManejador->generarCorazones();
			tiempoC = 0;
		}
		if (tiempoT >= 10)
		{
			oManejador->generarTreboles();
			tiempoT = 0;
		}
		//borrar mover dibujar y comprobar colision corazones siempre que existan corazones
		if (oManejador->cantCorazones() > 0)
		{
			oManejador->borrarCorazones();
			oManejador->moverCorazones();
			oManejador->dibujarCorazones();
			oManejador->colisionCorazonPersonaje();
		}
		//borrar mover dibujar y comprobar colision treboleses siempre que existan treboles
		if (oManejador->cantTreboles() > 0)
		{
			oManejador->borrarTreboles();
			oManejador->moverTreboles();
			oManejador->dibujarTreboles();
			oManejador->colisionTrebolPersonaje();
		}

		//borrar personaje y murcielago
		oManejador->borrarObjetos();

		//mover personaje y murcielago->pero personaje se mueve con la tecla y kbhit
		oManejador->moverMurcielago();
		if(kbhit())
		{
			int tecla = getch();
			oManejador->moverPersonaje(tecla);
		}
		//dibujar Personaje y murcielago

		oManejador->dibujarObjetos();

		//actualizat cantidad de vidas

		v = oManejador->devolverVidas();
		tiempoC++;
		tiempoT++;
		oManejador->setTiempo();
		oManejador->info();
		_sleep(200);
	}

	system("cls");
	Console::ForegroundColor = ConsoleColor::Yellow;
	Console::SetCursorPosition(30, 10);
	cout << "Cantidad de corazones obtenidos:" << oManejador->corazonesConseguidos();
	getch();
}