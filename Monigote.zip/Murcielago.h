#pragma once
#include <iostream>
#include <conio.h>
#include <time.h>
using namespace std;
using namespace System;

#define ANCHO 40
#define ALTO 20

class Murcielago
{
protected:
	int  x, y, dx;
	int ancho, alto;
public:
	Murcielago()

	{
		y = 0;
		x = 0;
		dx = 3;
		ancho = 17;
		alto = 4;
	}

	void dibujar()

	{
		Console::ForegroundColor = ConsoleColor::Gray;

		Console::SetCursorPosition(x, y + 0); cout << "  _   ,_,   _   ";
		Console::SetCursorPosition(x, y + 1); cout << " / `'=) (='` \\ ";
		Console::SetCursorPosition(x, y + 2); cout << "/.-.-.\\ /.-.-.\\ ";
		Console::SetCursorPosition(x, y + 3); cout << "`      ��   `";

	}
	void borrar()

	{
		Console::SetCursorPosition(x, y + 0); cout << "                 ";
		Console::SetCursorPosition(x, y + 1); cout << "                 ";
		Console::SetCursorPosition(x, y + 2); cout << "                 ";
		Console::SetCursorPosition(x, y + 3); cout << "                 ";

	}

	void mover()

	{
		if (x + dx<0 || x + dx + ancho>ANCHO)dx *= -1;
		x += dx;

	}

	int getX() { return x; }
	int getY() { return y; }
	int getAncho() { return ancho; }
	int getAlto() { return alto; }


};
