#pragma once
#include "Base.h"
#include "Monigote.h"
#include "Corazon.h"
#include "Murcielago.h"
#include "Trebol.h"

class Manejador 
{
private:
	vector<Corazon*>vCorazon;
	vector<Trebol*>vTrebol;
	Monigote* oPersonaje;
	Murcielago* objMurcielago;
	int cont = 0;

public:
	Manejador()
	{
		oPersonaje = new Monigote();
		objMurcielago = new Murcielago();
	}
	~Manejador()
	{}

	void generarCorazones()

	{
		int px = objMurcielago->getX() + objMurcielago->getAncho() / 2;
		int py = objMurcielago->getY() + objMurcielago->getAlto();
		vCorazon.push_back(new Corazon(px, py));
				
	}

	void generarTreboles()

	{
		int px = objMurcielago->getX() + objMurcielago->getAncho() / 2;
		int py = objMurcielago->getY() + objMurcielago->getAlto();
		vTrebol.push_back(new Trebol(px, py));

	}


	void dibujarObjetos()

	{
		oPersonaje->dibujar();
		objMurcielago->dibujar();

	}

	void moverPersonaje(int tecla)

	{
		oPersonaje->mover(tecla);
	}

	void moverMurcielago()

	{
		objMurcielago->mover();
	}

	void borrarObjetos()

	{
		oPersonaje->borrar();
		objMurcielago->borrar();
	}

	void dibujarCorazones()

	{
	  for(int i=0; i<vCorazon.size();i++)
	  {
		  vCorazon[i]->dibujar();
	  }
	
	}

	void dibujarTreboles()

	{
		for (int i = 0; i < vTrebol.size(); i++)
		{
			vTrebol[i]->dibujar();
		}

	}

	//eliminar corazon

	void eliminarCorazon(int pos)

	{
		vCorazon.erase(vCorazon.begin() + pos);
	}

	void moverCorazones()

	{
		for (int i = 0; i < vCorazon.size(); i++)
		{
			vCorazon[i]->mover();
			if (vCorazon[i]->getEstado() == 1)
				eliminarCorazon(i);
		}

	}

	//eliminar trebol

	void eliminarTrebol(int pos)

	{
		vTrebol.erase(vTrebol.begin() + pos);
	}

	void moverTreboles()

	{
		for (int i = 0; i < vTrebol.size(); i++)
		{
			vTrebol[i]->mover();
			if (vTrebol[i]->getEstado() == 1)
				eliminarTrebol(i);
		}

	}

	void borrarCorazones()

	{
		for (int i = 0; i < vCorazon.size(); i++)
		{
			vCorazon[i]->borrar();
		}
          
	}

	void borrarTreboles()

	{
		for (int i = 0; i < vTrebol.size(); i++)
		{
			vTrebol[i]->borrar();
		}

	}

	int devolverEstadoCorazon(int i)
	{
		return vCorazon[i]->getEstado();
	}

	int devolverEstadoTrebol(int i)
	{
		return vTrebol[i]->getEstado();
	}

	int devolverVidas()
	{
		return oPersonaje->getVidas();
	}

	int cantCorazones()
	{
		return vCorazon.size();
	}

	int cantTreboles()
	{
		return vTrebol.size(); 
	}

	void colisionCorazonPersonaje()
	{
		if (vCorazon.size()>0)
		{
			for (int i = 0; i < vTrebol.size(); i++)
			{

	          //coordenadas del corazon
				int x1 = vCorazon[i]->getX();
				int y1 = vCorazon[i]->getY();
				int w1 = vCorazon[i]->getAncho();
				int h1 = vCorazon[i]->getAlto();
			  //coordenadas del Personaje
				int x2 = oPersonaje->getX();
				int y2 = oPersonaje->getY();
				int w2 = oPersonaje->getAncho();
				int h2 = oPersonaje->getAlto();
				if (!(x1 > x2 + w2 || x1 + w1<x2 || y1 > y2 + y2 || y1 + h1 < y2))
				{
					vCorazon[i]->borrar();
					vCorazon.erase(vCorazon.begin() + i);
					oPersonaje->ganaVidas();
					oPersonaje->ganaCorazones();
				}


			}
		}
	}

	void colisionTrebolPersonaje()
	{
		if (vTrebol.size()>0)
		{
			for (int i = 0; i < vTrebol.size(); i++)
			{
				//coordenadas del corazon
				int x1 = vTrebol[i]->getX();
				int y1 = vTrebol[i]->getY();
				int w1 = vTrebol[i]->getAncho();
				int h1 = vTrebol[i]->getAlto();
				//coordenadas del Personaje
				int x2 = oPersonaje->getX();
				int y2 = oPersonaje->getY();
				int w2 = oPersonaje->getAncho();
				int h2 = oPersonaje->getAlto();
				if (!(x1 > x2 + w2 || x1 + w1<x2 || y1 > y2 + y2 || y1 + h1 < y2))
				{
					vTrebol[i]->borrar();
					vTrebol.erase(vTrebol.begin() + i);
					oPersonaje->pierdeVidas();
				}


			}
		}

	}

	int corazonesConseguidos()

	{
		return oPersonaje->getCorazones();
	}

	int getTiempo()

	{
		return cont;
	}

	void setTiempo()

	{
		cont++;
	}

	void info()

	{
		Console::SetCursorPosition(0, 17);
		cout << "Vidas:" << oPersonaje->getVidas();
		Console::SetCursorPosition(0, 18);
		cout << "Tiempo:" << getTiempo();
		Console::SetCursorPosition(0, 19);
		cout << "Corazones Conseguidos:" << oPersonaje->getCorazones();


	}
};
