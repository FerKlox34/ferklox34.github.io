#pragma once
#include "Base.h"
class Corazon :public Base
{
public:
	Corazon(int px, int py) :Base(px, py)

	{
		dy = 2;
	}

	void dibujar()

	{
		Console::ForegroundColor = ConsoleColor::Red;
		Console::SetCursorPosition(x, y);
		cout << char(3);
	}


};
