#pragma once
#include <iostream>
#include <conio.h>
using namespace std;
using namespace System;

#define izquierda 75
#define derecha 77

#define ANCHO 40


class Monigote
{
protected: 
	int  x, y, dx;
	int ancho, alto, vidas, corazones;
public:
	Monigote()

	{
		y = 14;
		x = 7;
		dx = 0;
		vidas = 1;
		corazones = 0;
		ancho = 3;
		alto = 3;
	}

	void dibujar ()

	{
		Console::ForegroundColor = ConsoleColor::White;

		Console::SetCursorPosition(x, y + 0); cout << " 0 ";
		Console::SetCursorPosition(x, y + 1); cout << "_|_";
		Console::SetCursorPosition(x, y + 2); cout << " | ";
	}
	void borrar()

	{
		Console::ForegroundColor = ConsoleColor::White;

		Console::SetCursorPosition(x, y + 0); cout << "   ";
		Console::SetCursorPosition(x, y + 1); cout << "   ";
		Console::SetCursorPosition(x, y + 2); cout << "   ";
	}
	void mover(int tecla)

	{ switch (tecla)
	   {
	     case izquierda: dx = -1; break;
	     case derecha: dx = 1; break;
	   }
	if (x + dx<0 || x + dx + ancho>ANCHO) dx *= -1; 
	    x += dx;
		dx = 0;
	}

	void pierdeVidas()
	{
		vidas--;
	}

	void ganaVidas()
	{
		vidas++;
	}


	int getX() { return x; }
	int getY() { return y; }
	int getAncho() { return ancho; }
	int getAlto() { return alto; }
	int getVidas() { return vidas; }
	int getCorazones() { return corazones; }
	void ganaCorazones() { corazones++; }


};
