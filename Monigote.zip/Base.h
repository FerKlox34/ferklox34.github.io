#pragma once
#include <iostream>
#include <conio.h>
#include <time.h>
#include <vector>
using namespace std;
using namespace System;

#define ANCHO 40
#define ALTO 16

class Base
{
protected:

	int x, y, dy;
	int estado, ancho, alto;

public:

	Base(int px, int py)//UBICACION EN X y Y, PARA SABER DONDE ESTA UBICADO EL OBEJTO EN LA CONSOLA

	{
		x = px;
		y = py;
		dy = 0;
		estado = 0;
		ancho = 1; //DEPENDE DEL TEL TREBOL Y CORAZON
		alto = 1;
	}

	virtual void dibujar()

	{}

	void mover()

	{
		if (y + dy + alto >= ALTO)

		{
			estado = 1;
			dy = 0;
		}

		y += dy;
	}
	
	void borrar()
	{
		for (int i = 0; i < alto; i++)
		{
			for (int j = 0; j < ancho; j++)
			{
				Console::SetCursorPosition(x + j, y + i);
				cout << " ";
			}

		}

	}

	int getDY() { return dy; }
	int getY() { return y; }
	int getAncho() { return ancho; }
	int getAlto() { return alto; }
	int getX() { return x; }
	int getEstado() { return estado; }

};